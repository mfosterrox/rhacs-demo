[proxy]
proxy_enabled = 
proxy_type = 
proxy_url = 
proxy_port = 
proxy_username = 
proxy_password = 
proxy_rdns = 

[logging]
loglevel = 

[additional_parameters]
central_endpoint = 
api_token = 